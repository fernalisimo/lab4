﻿using System;

namespace lab4.Tools.Exceptions
{
    public class IllegalDateException : Exception
    {

        public IllegalDateException(string birth) :
            base($"Your date {birth} is incorrect.")
        {
        }


    }
}
