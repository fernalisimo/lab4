﻿using System;

namespace lab4.Tools.Exceptions
{
    public class IllegalEmailException : Exception
    {

        public IllegalEmailException(string email)
            : base($"Your email {email} is not valid.")
        {
        }
    }
}
