﻿using System.Collections.Generic;
using lab4.Models;

namespace lab4.Tools.DataStorage
{
    internal interface IDataStorage
    {
        void AddUser(Person user);
        void DeleteUser(Person user);
        List<Person> UsersList { get; }
    }
}
