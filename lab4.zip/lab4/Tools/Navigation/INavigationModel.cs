﻿
namespace lab4.Tools.Navigation
{
    internal enum ViewType
    {
        AddUser,
        Main
    }

    interface INavigationModel
    {
        void Navigate(ViewType viewType);
    }
}
