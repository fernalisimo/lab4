﻿using System.Windows.Controls;

namespace lab4.Tools.Navigation
{
    internal interface IContentOwner
    {
        ContentControl ContentControl { get; }
    }
}
