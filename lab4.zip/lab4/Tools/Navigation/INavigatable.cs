﻿namespace lab4.Tools.Navigation
{
    internal interface INavigatable
    {
        
    }
   
}
