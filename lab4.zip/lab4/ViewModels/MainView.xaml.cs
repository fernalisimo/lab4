﻿using System.Windows.Controls;
using Practice7UserList.Tools.Navigation;

namespace Practice7UserList.Views
{
    public partial class MainView : UserControl, INavigatable
    {
        public MainView()
        {
            InitializeComponent();
          
        }

      
    }
}
