﻿using System.Windows.Controls;
using lab4.Tools.Navigation;
using lab4.ViewModels;

namespace lab4.Views.Authentication
{
    public partial class AddPersonView : UserControl, INavigatable
    {
        internal AddPersonView()
        {
            InitializeComponent();
            DataContext = new CreateUserViewModel();
        }

    }
}
