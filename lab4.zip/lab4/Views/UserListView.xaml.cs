﻿using System.Windows.Controls;
using lab4.Tools.Managers;
using lab4.Tools.Navigation;
using lab4.ViewModels;

namespace lab4.Views
{
    public partial class UserListView : UserControl, INavigatable
    {
        public UserListView()
        {
            InitializeComponent();
            StationManager.UpdateModel = new UserListViewModel();
            DataContext = StationManager.UpdateModel;

        }

    }
}
