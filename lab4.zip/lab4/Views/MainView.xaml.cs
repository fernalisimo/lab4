﻿using System.Windows.Controls;
using lab4.Tools.Navigation;

namespace lab4.Views
{
    public partial class MainView : UserControl, INavigatable
    {
        public MainView()
        {
            InitializeComponent();

        }


    }
}
